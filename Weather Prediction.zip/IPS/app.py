import streamlit as st
import numpy as np
import pandas as pd
import joblib

# Page config
st.set_page_config(page_title="Rain Prediction – Australia", layout="wide")

# Load model
@st.cache_resource
def load_model():
    return joblib.load("model.pkl")

model = load_model()

# Encoding helpers

LOCATIONS = [
    'Adelaide','Albany','Albury','AliceSprings','BadgerysCreek','Ballarat',
    'Bendigo','Brisbane','Cairns','Canberra','Cobar','CoffsHarbour','Dartmoor',
    'Darwin','GoldCoast','Hobart','Katherine','Launceston','Melbourne',
    'MelbourneAirport','Mildura','Moree','MountGambier','MountGinini',
    'Newcastle','Nhil','NorahHead','NorfolkIsland','Nuriootpa','PearceRAAF',
    'Penrith','Perth','PerthAirport','Portland','Richmond','Sale','SalmonGums',
    'Sydney','SydneyAirport','Townsville','Tuggeranong','Uluru','WaggaWagga',
    'Walpole','Watsonia','Williamtown','Witchcliffe','Wollongong','Woomera'
]

DIRECTIONS = [
    'E','ENE','ESE','N','NE','NNE','NNW','NW',
    'S','SE','SSE','SSW','SW','W','WNW','WSW'
]

def encode(value, sorted_list):
    """Alphabetical index — identical to sklearn LabelEncoder.transform."""
    return sorted_list.index(value)

# Date column
DATE_ENCODED = 0

# Page header
st.title("Rain Prediction System — Australia")
st.markdown("**XGBoost model** (tuned with Optuna) · trained on the Australian weather dataset")
st.markdown("---")

#Sidebar
st.sidebar.header("Weather Inputs")

st.sidebar.subheader("Location")
Location = st.sidebar.selectbox("Location", LOCATIONS, index=LOCATIONS.index("Sydney"))

st.sidebar.subheader("Temperature (°C)")
MinTemp  = st.sidebar.number_input("Min Temperature",     value=12.0, step=0.5)
MaxTemp  = st.sidebar.number_input("Max Temperature",     value=24.0, step=0.5)
Temp9am  = st.sidebar.number_input("Temperature at 9am",  value=17.0, step=0.5)
Temp3pm  = st.sidebar.number_input("Temperature at 3pm",  value=22.0, step=0.5)

st.sidebar.subheader("Humidity (%)")
Humidity9am = st.sidebar.number_input("Humidity at 9am", value=68.0, step=1.0, min_value=0.0, max_value=100.0)
Humidity3pm = st.sidebar.number_input("Humidity at 3pm", value=45.0, step=1.0, min_value=0.0, max_value=100.0)

st.sidebar.subheader("Pressure (hPa)")
Pressure9am = st.sidebar.number_input("Pressure at 9am", value=1015.0, step=0.5)
Pressure3pm = st.sidebar.number_input("Pressure at 3pm", value=1012.0, step=0.5)

st.sidebar.subheader("Wind")
WindGustDir   = st.sidebar.selectbox("Wind Gust Direction",    DIRECTIONS, index=DIRECTIONS.index("W"))
WindGustSpeed = st.sidebar.number_input("Wind Gust Speed (km/h)",  value=41.0, step=1.0, min_value=0.0)
WindDir9am    = st.sidebar.selectbox("Wind Direction at 9am",  DIRECTIONS, index=DIRECTIONS.index("W"))
WindDir3pm    = st.sidebar.selectbox("Wind Direction at 3pm",  DIRECTIONS, index=DIRECTIONS.index("S"))
WindSpeed9am  = st.sidebar.number_input("Wind Speed at 9am (km/h)", value=15.0, step=1.0, min_value=0.0)
WindSpeed3pm  = st.sidebar.number_input("Wind Speed at 3pm (km/h)", value=20.0, step=1.0, min_value=0.0)

st.sidebar.subheader("Other")
Rainfall    = st.sidebar.number_input("Rainfall (mm)",              value=0.0, step=0.5, min_value=0.0)
Evaporation = st.sidebar.number_input("Evaporation (mm)",           value=5.0, step=0.5, min_value=0.0)
Sunshine    = st.sidebar.number_input("Sunshine (hrs)",             value=7.0, step=0.5, min_value=0.0, max_value=14.0)
Cloud9am    = st.sidebar.number_input("Cloud cover at 9am (oktas)", value=3.0, step=1.0, min_value=0.0, max_value=8.0)
Cloud3pm    = st.sidebar.number_input("Cloud cover at 3pm (oktas)", value=4.0, step=1.0, min_value=0.0, max_value=8.0)
RainToday   = st.sidebar.selectbox("Rained today?", ["No", "Yes"])

st.sidebar.markdown("---")
st.sidebar.caption("Model: XGBoost (Optuna-tuned)")
st.sidebar.caption("Dataset: Rain in Australia — Kaggle")
st.sidebar.caption("Accuracy ≈ 86%")


TempRange       = MaxTemp     - MinTemp
PressureChange  = Pressure3pm - Pressure9am
HumidityChange  = Humidity3pm - Humidity9am
WindSpeedChange = WindSpeed3pm - WindSpeed9am
AvgTemp         = (MinTemp + MaxTemp) / 2

# Show derived features
st.subheader("Derived Features")
c1, c2, c3, c4, c5 = st.columns(5)
c1.metric("Temp range",        f"{TempRange:.1f} °C")
c2.metric("Pressure change",   f"{PressureChange:+.1f} hPa")
c3.metric("Humidity change",   f"{HumidityChange:+.1f} %")
c4.metric("Wind speed change", f"{WindSpeedChange:+.1f} km/h")
c5.metric("Average temp",      f"{AvgTemp:.1f} °C")

st.markdown("---")

# Predict
if st.button("Predict Rain Tomorrow", use_container_width=True, type="primary"):

    # Encode categorical inputs (alphabetical index = LabelEncoder output)
    location_enc    = encode(Location,    LOCATIONS)
    wind_gust_enc   = encode(WindGustDir, DIRECTIONS)
    wind_dir9am_enc = encode(WindDir9am,  DIRECTIONS)
    wind_dir3pm_enc = encode(WindDir3pm,  DIRECTIONS)
    rain_today_enc  = 1 if RainToday == "Yes" else 0


    feature_names = [
        'Date', 'Location', 'MinTemp', 'MaxTemp', 'Rainfall', 'Evaporation',
        'Sunshine', 'WindGustDir', 'WindGustSpeed', 'WindDir9am', 'WindDir3pm',
        'WindSpeed9am', 'WindSpeed3pm', 'Humidity9am', 'Humidity3pm',
        'Pressure9am', 'Pressure3pm', 'Cloud9am', 'Cloud3pm', 'Temp9am',
        'Temp3pm', 'RainToday', 'TempRange', 'PressureChange',
        'HumidityChange', 'WindSpeedChange', 'AvgTemp'
    ]

    feature_values = [[
        DATE_ENCODED,    
        location_enc,    
        MinTemp,         
        MaxTemp,         
        Rainfall,        
        Evaporation,     
        Sunshine,       
        wind_gust_enc,   
        WindGustSpeed,   
        wind_dir9am_enc, 
        wind_dir3pm_enc, 
        WindSpeed9am,    
        WindSpeed3pm,    
        Humidity9am,     
        Humidity3pm,     
        Pressure9am,     
        Pressure3pm,     
        Cloud9am,        
        Cloud3pm,        
        Temp9am,         
        Temp3pm,        
        rain_today_enc,  # RainToday
        TempRange,       # (derived)
        PressureChange,  # (derived)
        HumidityChange,  # (derived)
        WindSpeedChange, # (derived)
        AvgTemp,         # (derived)
    ]]

    features_df = pd.DataFrame(feature_values, columns=feature_names)

    prediction  = model.predict(features_df)[0]
    probability = model.predict_proba(features_df)[0][1]

    # Result display
    st.subheader("Prediction Result")
    res_col, prob_col = st.columns([1, 2])

    with res_col:
        if prediction == 1:
            st.error("**Rain expected tomorrow**")
        else:
            st.success("**No rain tomorrow**")
        st.metric("Rain probability", f"{probability * 100:.1f} %")

    with prob_col:
        st.write("Probability gauge")
        st.progress(float(probability))
        if probability >= 0.70:
            st.warning("High probability — very likely to rain.")
        elif probability >= 0.40:
            st.info("Moderate probability — uncertain conditions.")
        else:
            st.success("Low probability — likely to stay dry.")